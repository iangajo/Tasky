﻿namespace ImageProcessorInterface
{
    public interface IProcessor
    {
        string Process();
    }
}
