﻿using ImageProcessorInterface;

namespace GifProcessor
{
    public class GifProcessor : IProcessor
    {
        public string Process()
        {
            return "GIF Processed.";
        }
    }
}
